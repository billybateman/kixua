import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { IDE } from './pages/IDE/IDE';
import { AIChatOffcanvas } from './components/AIChatOffcanvas';
import 'bootstrap/dist/js/bootstrap.bundle.min.js';
import './pages/IDE/styles/ide.css';
import './styles/ai-chat.css';

document.addEventListener('DOMContentLoaded', () => {
    const app = document.getElementById('app');
    app.innerHTML = `
        ${Sidebar()}
        <div class="main-content">
            ${Header()}
            ${IDE()}
        </div>
       ${AIChatOffcanvas()}
    `;

    document.getElementById('sidebarCollapse')?.addEventListener('click', () => {
        document.getElementById('sidebar')?.classList.toggle('active');
    });
});