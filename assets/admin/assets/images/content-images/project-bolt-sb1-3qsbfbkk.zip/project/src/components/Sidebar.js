export function Sidebar() {
    return `
        <nav id="sidebar" class="sidebar">
            <div class="sidebar-logo">
                <img src="https://via.placeholder.com/120x35" alt="Logo">
            </div>
            <ul class="nav flex-column pt-3">
                <li class="nav-item">
                    <a href="#" class="nav-link active">
                        <i class="bi bi-grid"></i>
                        Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link">
                        <i class="bi bi-kanban"></i>
                        Projects
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link">
                        <i class="bi bi-people"></i>
                        Teams
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link">
                        <i class="bi bi-calendar3"></i>
                        Calendar
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link">
                        <i class="bi bi-chat-dots"></i>
                        Messages
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link">
                        <i class="bi bi-gear"></i>
                        Settings
                    </a>
                </li>
            </ul>
        </nav>
    `;
}