export function Terminal() {
    return `
        <div class="ide-terminal">
            <div class="terminal-header">
                <div class="terminal-tabs">
                    <span class="active">Terminal</span>
                    <span>Output</span>
                    <span>Problems</span>
                </div>
                <div class="terminal-actions">
                    <button class="btn btn-sm"><i class="bi bi-plus"></i></button>
                    <button class="btn btn-sm"><i class="bi bi-dash"></i></button>
                    <button class="btn btn-sm"><i class="bi bi-x"></i></button>
                </div>
            </div>
            <div class="terminal-content">
                <div class="terminal-line">
                    <span class="prompt">$</span>
                    <span class="command">npm start</span>
                </div>
            </div>
        </div>
    `;
}