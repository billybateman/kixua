export function Header() {
    return `
        <header class="main-header d-flex align-items-center justify-content-between">
            <div class="d-flex align-items-center">
                <button type="button" id="sidebarCollapse" class="btn d-lg-none">
                    <i class="bi bi-list"></i>
                </button>
                <div class="header-search position-relative ms-3">
                    <input type="text" class="form-control" placeholder="Search for anything...">
                    <i class="bi bi-search search-icon"></i>
                </div>
            </div>
            <div class="d-flex align-items-center">
                <button class="btn me-3" type="button" data-bs-toggle="offcanvas" data-bs-target="#aiChatPanel">
                    <i class="bi bi-robot"></i>
                </button>
                <div class="dropdown me-3">
                    <button class="btn position-relative" type="button">
                        <i class="bi bi-bell"></i>
                        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                            3
                        </span>
                    </button>
                </div>
                <div class="dropdown">
                    <button class="btn d-flex align-items-center" type="button">
                        <img src="https://via.placeholder.com/32" class="rounded-circle me-2" alt="User">
                        <div class="d-none d-md-block">
                            <div class="fw-bold">John Doe</div>
                            <small class="text-muted">Administrator</small>
                        </div>
                    </button>
                </div>
            </div>
        </header>
    `;
}