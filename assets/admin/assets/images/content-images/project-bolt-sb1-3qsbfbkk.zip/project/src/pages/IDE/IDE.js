import { IconMenu } from './components/IconMenu';
import { FileManager } from './components/FileManager';
import { CodeEditor } from './components/CodeEditor';
import { Terminal } from './components/Terminal';


export function IDE() {
    return `
        <div class="ide-container">
            ${IconMenu()}
            ${FileManager()}
            <div class="editor-container">
                ${CodeEditor()}
                ${Terminal()}
            </div>
           
        </div>
    `;
}