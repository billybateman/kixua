export function FileManager() {
    return `
        <div class="ide-file-manager">
            <div class="file-manager-header">
                <h6 class="mb-0">EXPLORER</h6>
                <div class="file-manager-actions">
                    <button class="btn btn-sm"><i class="bi bi-file-earmark-plus"></i></button>
                    <button class="btn btn-sm"><i class="bi bi-folder-plus"></i></button>
                    <button class="btn btn-sm"><i class="bi bi-arrow-clockwise"></i></button>
                </div>
            </div>
            <div class="file-tree">
                <div class="folder-item">
                    <i class="bi bi-chevron-right"></i>
                    <i class="bi bi-folder-fill"></i>
                    <span>src</span>
                </div>
                <div class="folder-item">
                    <i class="bi bi-chevron-right"></i>
                    <i class="bi bi-folder-fill"></i>
                    <span>public</span>
                </div>
                <div class="file-item">
                    <i class="bi bi-file-earmark-code"></i>
                    <span>index.html</span>
                </div>
                <div class="file-item">
                    <i class="bi bi-file-earmark-text"></i>
                    <span>package.json</span>
                </div>
            </div>
        </div>
    `;
}