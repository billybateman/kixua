export function IconMenu() {
    return `
        <div class="ide-icon-menu">
            <div class="icon-menu-item active" title="Explorer">
                <i class="bi bi-files"></i>
            </div>
            <div class="icon-menu-item" title="Search">
                <i class="bi bi-search"></i>
            </div>
            <div class="icon-menu-item" title="Git">
                <i class="bi bi-git"></i>
            </div>
            <div class="icon-menu-item" title="Debug">
                <i class="bi bi-bug"></i>
            </div>
            <div class="icon-menu-item" title="Extensions">
                <i class="bi bi-box"></i>
            </div>
        </div>
    `;
}