export function AIChatOffcanvas() {
    return `
        <div class="offcanvas offcanvas-end ai-chat-offcanvas" tabindex="-1" id="aiChatPanel">
            <div class="offcanvas-header">
                <h5 class="offcanvas-title">AI Assistant</h5>
                <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
            </div>
            <div class="offcanvas-body d-flex flex-column">
                <div class="chat-messages flex-grow-1">
                    <div class="message assistant">
                        <div class="message-content">
                            <p>Hello! How can I help you with your code today?</p>
                        </div>
                    </div>
                </div>
                <div class="chat-input-container">
                    <textarea class="form-control mb-2" rows="3" placeholder="Ask a question..."></textarea>
                    <button class="btn btn-primary w-100">
                        Send <i class="bi bi-send ms-1"></i>
                    </button>
                </div>
            </div>
        </div>
    `;
}