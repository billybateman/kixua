export function CodeEditor() {
    return `
        <div class="ide-code-editor">
            <div class="editor-tabs">
                <div class="tab active">
                    <span>index.html</span>
                    <button class="btn btn-sm close-tab"><i class="bi bi-x"></i></button>
                </div>
                <div class="tab">
                    <span>style.css</span>
                    <button class="btn btn-sm close-tab"><i class="bi bi-x"></i></button>
                </div>
            </div>
            <div class="editor-content">
                <pre class="code-area">
&lt;!DOCTYPE html&gt;
&lt;html lang="en"&gt;
&lt;head&gt;
    &lt;meta charset="UTF-8"&gt;
    &lt;title&gt;Document&lt;/title&gt;
&lt;/head&gt;
&lt;body&gt;
    
&lt;/body&gt;
&lt;/html&gt;</pre>
            </div>
        </div>
    `;
}