export function ProjectList() {
    return `
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h6 class="mb-0">Projects List</h6>
                <button class="btn btn-primary btn-sm">
                    <i class="bi bi-plus"></i> Add Project
                </button>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table mb-0">
                        <thead>
                            <tr>
                                <th>Project</th>
                                <th>Team</th>
                                <th>Status</th>
                                <th>Progress</th>
                                <th>Deadline</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="project-icon me-3 bg-primary-subtle rounded p-2">
                                            <i class="bi bi-briefcase text-primary"></i>
                                        </div>
                                        <div>
                                            <h6 class="mb-0">Website Redesign</h6>
                                            <small class="text-muted">Web Design</small>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="avatar-group">
                                        <img src="https://via.placeholder.com/32" class="rounded-circle" alt="User">
                                        <img src="https://via.placeholder.com/32" class="rounded-circle" alt="User">
                                        <img src="https://via.placeholder.com/32" class="rounded-circle" alt="User">
                                    </div>
                                </td>
                                <td>
                                    <span class="badge bg-success-subtle text-success">Completed</span>
                                </td>
                                <td>
                                    <div class="progress" style="height: 5px;">
                                        <div class="progress-bar bg-success" style="width: 100%"></div>
                                    </div>
                                </td>
                                <td>25 Nov 2023</td>
                                <td>
                                    <div class="dropdown">
                                        <button class="btn btn-sm" type="button">
                                            <i class="bi bi-three-dots-vertical"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            <!-- Add more project rows here -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    `;
}